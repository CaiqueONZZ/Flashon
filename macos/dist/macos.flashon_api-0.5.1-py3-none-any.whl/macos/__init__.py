import subprocess

subprocess.run(['python3','-m','sdist'])
